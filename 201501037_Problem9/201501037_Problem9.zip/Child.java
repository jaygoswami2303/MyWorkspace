/** 
 * Problem 9
 * @author Jay Goswami
 * SID:    201501037
 */

public class Child extends Passenger
{
	public Child(String name,char origin,char destination)
	{
		super(name,20,60,origin,destination);
	}
}