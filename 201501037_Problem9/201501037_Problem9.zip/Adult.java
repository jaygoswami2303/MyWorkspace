/** 
 * Problem 9
 * @author Jay Goswami
 * SID:    201501037
 */

public class Adult extends Passenger
{
	public Adult(String name,char origin,char destination)
	{
		super(name,10,10,origin,destination);
	}
}