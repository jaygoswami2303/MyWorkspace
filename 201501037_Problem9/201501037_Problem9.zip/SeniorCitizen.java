/** 
 * Problem 9
 * @author Jay Goswami
 * SID:    201501037
 */

public class SeniorCitizen extends Passenger
{
	public SeniorCitizen(String name,char origin,char destination)
	{
		super(name,20,20,origin,destination);
	}
}